﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    public enum RangeOperator
    {
        None = 0,
        LessThan,
        LessThanOrEquals,
        Equals,
        GreaterThanOrEquals,
        GreaterThan
    }
}