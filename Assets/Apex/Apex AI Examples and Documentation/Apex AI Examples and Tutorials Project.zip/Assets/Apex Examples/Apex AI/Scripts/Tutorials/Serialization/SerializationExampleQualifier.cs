﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    using Apex.Serialization;

    public sealed class SerializationExampleQualifier : QualifierBase
    {
        [ApexSerialization]
        public ICustomType customSettings;

        public override float Score(IAIContext context)
        {
            return 0f;
        }
    }
}