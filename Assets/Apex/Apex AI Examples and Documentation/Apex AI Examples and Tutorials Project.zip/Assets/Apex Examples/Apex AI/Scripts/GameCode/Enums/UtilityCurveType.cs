﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    public enum UtilityCurveType
    {
        Linear,
        ReversedLinear,
        Exponential,
        ReversedExponential,
        Logistic,
        ReversedLogistic,
        Logit,
        ReversedLogit,
        Gaussian,
        ReversedGaussian
    }
}