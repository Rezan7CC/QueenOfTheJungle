﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    public sealed class ExampleMemoryCleanup : ActionBase
    {
        public override void Execute(IAIContext context)
        {
            var c = (ExampleContext)context;

            var observations = c.observations;
            var count = observations.Count;
            if (count == 0)
            {
                return;
            }

            // must loop backwards to enable removing elements from the list while iterating through it
            for (int i = count - 1; i >= 0; i--)
            {
                var obs = observations[i];
                if (obs != null)
                {
                    continue;
                }

                c.observations.RemoveAt(i);
            }
        }
    }
}