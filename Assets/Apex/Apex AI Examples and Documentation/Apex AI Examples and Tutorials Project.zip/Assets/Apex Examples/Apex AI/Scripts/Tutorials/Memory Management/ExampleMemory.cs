﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    using System.Collections.Generic;

    public class ExampleMemory
    {
        private List<ExampleObservation> _observations;

        public ExampleMemory()
        {
            _observations = new List<ExampleObservation>(10);
        }

        public List<ExampleObservation> allObservations
        {
            get { return _observations; }
        }

        public void AddOrUpdateObservation(ExampleObservation observation, bool checkTimestamp)
        {
            var count = _observations.Count;
            for (int i = 0; i < count; i++)
            {
                var obs = _observations[i];
                if (!object.ReferenceEquals(obs.gameObject, observation.gameObject))
                {
                    continue;
                }

                if (checkTimestamp && obs.timestamp >= observation.timestamp)
                {
                    return;
                }

                _observations[i] = observation;
                return;
            }

            _observations.Add(observation);
        }

        public void RemoveObservationAt(int index)
        {
            _observations.RemoveAt(index);
        }
    }
}