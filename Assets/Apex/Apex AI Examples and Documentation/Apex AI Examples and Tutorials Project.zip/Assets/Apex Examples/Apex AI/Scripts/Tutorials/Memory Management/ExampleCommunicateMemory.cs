﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    using System;
    using AI.Components;
    using Apex.Serialization;

    public sealed class ExampleCommunicateMemory : ActionBase
    {
        [ApexSerialization]
        public float maxRange = 25f;

        public override void Execute(IAIContext context)
        {
            var c = (ExampleContext)context;

            var rangeSqr = this.maxRange * this.maxRange;
            var observations = c.observations;
            var count = observations.Count;

            for (int i = 0; i < count; i++)
            {
                var obs = observations[i];
                if ((obs.transform.position - c.self.transform.position).sqrMagnitude > rangeSqr)
                {
                    continue;
                }

                var added = false;

                // Please note that the following is a simplification which is not highly performant, there should be another way for getting access to another's memory
                // iterate through the observed game object's memories to check for duplicates
                var ctxProvider = (IContextProvider)obs.GetComponent(typeof(IContextProvider));
                var ctx = (ExampleContext)ctxProvider.GetContext(Guid.Empty);
                var ctxCount = ctx.observations.Count;
                for (int j = 0; j < ctxCount; j++)
                {
                    var ctxObs = ctx.observations[j];
                    if (object.ReferenceEquals(ctxObs, obs))
                    {
                        // existing observation found, no need for adding it then
                        added = true;
                        break;
                    }
                }

                if (!added)
                {
                    ctx.observations.Add(obs);
                }
            }
        }
    }
}