﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Game
{
    public sealed class MarineComponent : EntityComponentBase
    {
        public override EntityType type
        {
            get { return EntityType.Marine; }
        }
    }
}